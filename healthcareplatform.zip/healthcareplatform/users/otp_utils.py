import random
import requests

FAST2SMS_API_KEY = ''

def generate_otp():
    return str(random.randint(100000, 999999))

pheon_number = ""

def send_otp_via_sms(phone_number, otp):
    url = "https://www.fast2sms.com/dev/bulkV2"
    headers = {
        'authorization': FAST2SMS_API_KEY,
        'Content-Type': "application/x-www-form-urlencoded"
    }
    data = {
        'variables_values': otp,
        'route': 'otp',
        'numbers': phone_number
    }
    response = requests.post(url, headers=headers, data=data)
    return response.json()
