from django.urls import path
from .views import (
    register_view,
    send_otp_view,
    verify_otp_view,
    dashboard_view,
    profile_view,
    update_profile_view,
    doctor_profile_view,
    doctor_availability_view,
    prescription_view,
    doctor_appointments_view,
    home_view,
    book_appointment_view,  # <-- comma here!
)


urlpatterns = [
    path('register/', register_view, name='register'),
    path('send-otp/', send_otp_view, name='send_otp'),
    path('verify-otp/', verify_otp_view, name='verify_otp'),
    path('dashboard/', dashboard_view, name='dashboard'),
    path('profile/', profile_view, name='profile'),
    path('profile/update/', update_profile_view, name='update_profile'),
    path('doctor/profile/', doctor_profile_view, name='doctor_profile'),
    path('doctor/availability/', doctor_availability_view, name='doctor_availability'),
    path('doctor/prescription/', prescription_view, name='prescription'),
    path('doctor/appointments/', doctor_appointments_view, name='doctor_appointments'),
    path('', home_view, name='home'),
    path('book-appointment/', book_appointment_view, name='book_appointment'),
]
