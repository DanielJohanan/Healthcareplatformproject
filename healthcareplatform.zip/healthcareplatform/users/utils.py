
import requests

def send_sms(phone, otp):
    url = "https://www.fast2sms.com/dev/bulkV2"
    payload = {
        "authorization": "f6hurne4kxERsByDdazJg1iFl75UCTmwYQMv9Pt03KXS2oIHAZv2Or3ixfDtb519RcZjgN7GYsQ8kSXT",  
        "message": f"Your OTP is {otp}",
        "language": "english",
        "route": "q",
        "numbers": phone,
    }
    headers = {
        'cache-control': "no-cache"
    }

    response = requests.post(url, data=payload, headers=headers)
    return response.json()
