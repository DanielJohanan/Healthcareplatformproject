from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from .models import CustomUser, DoctorProfile, DoctorAvailability, Prescription
from .forms import CustomUserCreationForm, ProfileForm, DoctorProfileForm, DoctorAvailabilityForm, PrescriptionForm
from django.urls import reverse
from .forms import AppointmentForm
from .models import DoctorAvailability, Appointment
import random
from django.core.mail import send_mail
from .models import Appointment
from .forms import AppointmentForm


def home_view(request):
    return render(request, "home.html")




def register_view(request):
    if request.method == "POST":
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("send_otp")
    else:
        form = CustomUserCreationForm()
    return render(request, "users/register.html", {"form": form})

def send_otp_view(request):
    if request.method == "POST":
        email = request.POST.get("email")
        try:
            user = CustomUser.objects.get(email=email)
            otp = str(random.randint(100000, 999999))
            user.otp = otp
            user.otp_created_at = timezone.now()
            user.save()

            # Actually send email
            send_mail(
                'Your OTP Code',
                f'Your OTP code is {otp}',
                'danielmedia44@gmail.com',  # from email (same as EMAIL_HOST_USER)
                [email],
                fail_silently=False,
            )

            request.session["otp"] = otp
            request.session["email"] = email
            request.session["otp_created_at"] = timezone.now().isoformat()

            messages.success(request, f"OTP sent to {email}. Please check your inbox.")
            return redirect("verify_otp")
        except CustomUser.DoesNotExist:
            messages.error(request, "User with this email does not exist.")
    return render(request, "users/send_otp.html")

def verify_otp_view(request):
    if request.method == "POST":
        otp = request.POST.get("otp")
        email = request.session.get("email")

        if not email:
            messages.error(request, "Session expired. Please try again.")
            return redirect("send_otp")

        try:
            user = CustomUser.objects.get(email=email, otp=otp)
            if user.otp_created_at and timezone.now() - user.otp_created_at <= timedelta(minutes=5):
                request.session["user_id"] = user.id
                request.session["user_role"] = user.role
                messages.success(request, "OTP verified successfully. You are logged in.")
                return redirect("dashboard")
            else:
                messages.error(request, "OTP expired. Please request a new one.")
                return redirect("send_otp")
        except CustomUser.DoesNotExist:
            messages.error(request, "Invalid OTP. Please try again.")
            return redirect("verify_otp")
    return render(request, "users/verify_otp.html")

def dashboard_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")
    user = CustomUser.objects.get(id=user_id)

    # Fetch doctor's availabilities if doctor
    availabilities = None
    if user.role == "doctor":
        availabilities = DoctorAvailability.objects.filter(doctor=user)

    return render(request, "users/dashboard.html", {
        "user": user,
        "availabilities": availabilities,
    })

def profile_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")
    user = CustomUser.objects.get(id=user_id)
    return render(request, "users/profile.html", {"user": user})

def update_profile_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")
    user = CustomUser.objects.get(id=user_id)

    if request.method == "POST":
        form = ProfileForm(request.POST, instance=user)
        if form.is_valid():
            updated_user = form.save(commit=False)

            # Check if new password is provided (from the form field new_password)
            new_password = form.cleaned_data.get("new_password")
            if new_password:
                updated_user.set_password(new_password)

            updated_user.save()
            messages.success(request, "Profile updated successfully.")

            # Optionally, refresh session or re-login logic here
            # You can keep the user logged in unless you want to force re-login
            return redirect("profile")
    else:
        form = ProfileForm(instance=user)

    return render(request, "users/update_profile.html", {"form": form})


def doctor_profile_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")
    user = CustomUser.objects.get(id=user_id)

    try:
        profile = DoctorProfile.objects.get(user=user)
    except DoctorProfile.DoesNotExist:
        profile = None

    if request.method == "POST":
        form = DoctorProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            new_profile = form.save(commit=False)
            new_profile.user = user
            new_profile.save()
            messages.success(request, "Doctor profile updated.")
            return redirect("dashboard")
    else:
        form = DoctorProfileForm(instance=profile)

    return render(request, "users/doctor_profile.html", {"form": form})


def doctor_availability_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")
    user = CustomUser.objects.get(id=user_id)

    if request.method == "POST":
        form = DoctorAvailabilityForm(request.POST)
        if form.is_valid():
            availability = form.save(commit=False)
            availability.doctor = user
            availability.save()
            messages.success(request, "Availability updated.")
            return redirect("doctor_availability")
    else:
        form = DoctorAvailabilityForm()

    # Get all availabilities for this doctor
    availabilities = DoctorAvailability.objects.filter(doctor=user)

    return render(request, "users/availability.html", {"form": form, "availabilities": availabilities})


def prescription_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")
    user = CustomUser.objects.get(id=user_id)

    if request.method == "POST":
        form = PrescriptionForm(request.POST, request.FILES)
        if form.is_valid():
            prescription = form.save(commit=False)
            prescription.doctor = user
            prescription.save()
            messages.success(request, "Prescription added.")
            return redirect("dashboard")
    else:
        form = PrescriptionForm()
    return render(request, "users/prescription.html", {"form": form})

def doctor_appointments_view(request):
    if "user_id" not in request.session:
        return redirect("send_otp")
    return render(request, "users/doctor_appointments.html")

def book_appointment_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return redirect("send_otp")

    user = CustomUser.objects.get(id=user_id)
    if user.role != "patient":
        messages.error(request, "Only patients can book appointments.")
        return redirect("dashboard")

    if request.method == "POST":
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.patient = user
            appointment.save()
            messages.success(request, "Appointment booked successfully.")
            return redirect("dashboard")
    else:
        form = AppointmentForm()

    return render(request, "users/book_appointment.html", {"form": form})
